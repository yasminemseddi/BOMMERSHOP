<?php
//include '../../model/billet.php';
class reclamationC {
    function afficherreclamation(){
        $sql="SELECT * FROM reclamation";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur:' . $e->getMessage());
        }
    }
        function trirec(){
        $sql="SELECT * FROM reclamation order by nom";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur:' . $e->getMessage());
        }
    }
    function supprimerreclamation($id){
        $sql=" DELETE FROM reclamation WHERE id_reclamation=:id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id' , $id);
        try{
            $req->execute();
        }
        catch(Exception $e){
            die('Erreur:' . $e->getMessage());
        }
    }




function AJouterrec($res)
{
    $sqlc= "INSERT INTO `reclamation` VALUES (:id,:nm,:prenm,:recl,:mail,:etat,:uti)";
$db=config::getConnexion();
try{ $recipesStatement = $db->prepare($sqlc);
    $recipesStatement->execute(['id'=>$res->getid(),
            'nm'=>$res->getnom(),
            'prenm'=> $res->getprenom(),
           'recl'=>$res->getreclamation(),
            'mail'=>$res->getmail(),
            'etat'=> $res->getetat(),
                 'uti'=> $res->getuti(),



    ]);
 }
 catch(Exception $e){ 
    
             die("erreur:".$e->getMessage());
}
}


    function modifierrec($res)
{
$sqlc= "UPDATE `reclamation` SET nom=:nom,prenom=:prenom,reclamation=:recl,mail=:mail,id_utlisitarur=:uti WHERE id_reclamation=:id  ";
$db=config::getConnexion();
try{ $recipesStatement = $db->prepare($sqlc);
    $recipesStatement->execute([  'id'=>$res->getid(),
            'nom'=>$res->getnom(),
            'prenom'=> $res->getprenom(),
           'recl'=>$res->getreclamation(),
            'mail'=>$res->getmail(),
           'uti'=> $res->getuti(),
                 
                 ]);
}
 catch(Exception $e){ 
    
             die("erreur:".$e->getMessage());
}

}

  function afficherreclamationtraite(){
        $sql="SELECT * FROM reclamation where etat like 0";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur:' . $e->getMessage());
        }
    }

   function afficherrutilisateur(){
        $sql="SELECT * FROM utilisateur";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur:' . $e->getMessage());
        }
    }
}
?>