<?php
//include_once '../config.php';
class reclamation
{ 
    private  $id;
    private  $nom;
  private  $prenom;
     private  $reclamation;
    private  $mail;
  private  $etat;
   private  $uti;
public function __construct($id,$nom,$prenom,$reclamation,$mail,$uti){
    $this->id = $id;
    $this->nom = $nom;
    $this->prenom = $prenom;
        $this->reclamation = $reclamation;
    $this->mail = $mail;
    $this->etat =0;
     $this->uti =$uti;
   
}

public function getid(){
    return $this->id ;
}
public function getnom(){
    return $this->nom ;
}
public function getprenom(){
    return $this->prenom ;
}
public function getreclamation(){
    return $this->reclamation ;
}
public function getmail(){
    return $this->mail ;
}
public function getetat(){
    return $this->etat ;
}
public function getuti(){
    return $this->uti ;
}
    
}
?>