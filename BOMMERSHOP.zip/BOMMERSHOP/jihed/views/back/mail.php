<?php
$destinataire =$_POST['mail']; 
$sujet = "Sujet"; // sujet du mail
$message =$_POST['rep']; 
mail ($destinataire, $sujet, $message);

include_once '../../config.php';


$db=config::getConnexion();
$sql="UPDATE `reclamation` SET etat=:etat WHERE id_reclamation=:id  ";
$recipesStatement = $db->prepare($sql);
 $recipesStatement->execute([  'id'=>$_POST['id'],
            'etat'=>1,
  
                 
                 ]);




header('location:Evenement.php');
?>