<?php
include_once '../../config.php';
include '../../controller/BilletC.php';
include '../../model/billet.php';



 if(!isset($_POST['ref'])||!isset($_POST['quantiter'])||!isset($_POST['prix']))
{
	echo "erreur de ";
}
$billetC=new billetC();
$billet=new billet($_POST['ref'],$_POST['quantiter'],$_POST['prix']);
$listeBillet=$billetC->modifierBillet($billet);
header('location:Evenement.php');
?>


