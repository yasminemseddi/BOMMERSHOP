<?php
include_once '../../config.php';
include '../../controller/BilletC.php';
include '../../model/reservation.php';



 if(!isset($_POST['id'])||!isset($_POST['nom'])||!isset($_POST['prenom'])||!isset($_POST['age'])||!isset($_POST['adresse'])||!isset($_POST['quant']))
{
	echo "erreur de ";
}
$billetC=new billetC();
$res=new reservation($_POST['id'],$_POST['nom'],$_POST['prenom'],$_POST['age'],$_POST['adresse'],$_POST['quant']);

$listeBillet=$billetC-> modifierres($res);
header('location:profile.php');
?>