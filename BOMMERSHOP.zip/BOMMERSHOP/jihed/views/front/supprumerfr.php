<?php
include_once '../../config.php';
include '../../controller/reclamationC.php';

$reclamationC=new reclamationC();
$rec=$reclamationC->supprimerreclamation($_POST['rec']);
header('location:index.php');

?>
