<?php
include_once '../../config.php';
include '../../controller/reclamationC.php';

$reclamationC=new reclamationC();
$listerec=$reclamationC->afficherrutilisateur();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>Pixie - Ecommerce HTML5 Template</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/tooplate-main.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <!--
Tooplate 2114 Pixie
https://www.tooplate.com/view/2114-pixie
-->
</head>

<body>

    <!-- Pre Header -->
    <div id="pre-header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <span>Merci pour votre visite </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <nav class="navbar navbar-light bg-light">
                <div class="container">
                    <a class="navbar-brand" href="index.php
                    ">
                        <img src="C:\Users\dell\Desktop\BOMMERSHOP\2114_pixie\sources\logo.svg" alt="" width="150"
                            height="150">
                    </a>
                </div>
            </nav>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../../../index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../../about.html">A propos</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="../../../products.html" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="true">
                            Produits
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled">chercher</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../../../connexion.php">Connexion</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../../../regester.php">Registre</a>
                    </li>
                </ul>
                <form class="d-flex">
            
               

                </form>
            </div>
        </div>
    </nav>
     '<script>
          function check(){
            
                  var nomR=document.frm.nom.value;
                      var letters = /^[A-Za-z]+$/;
              if (!(nomR.match(letters) && nomR.charAt(0).match(/^[A-Z]+$/))){
                  document.getElementById("msg").innerHTML="Entrez uniquement Le premier chiffre en MAJ";
                  return false;
              }else{
                  return true;
              }
          }
       </script>'

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="container">
            <div class="row">
             <form name="frm"  method="post" action="ajouterrecfct.php" enctype="multipart/form-data" onsubmit="return check()">
        <center><legend><h2>Ajouter Reclamation</h2></legend></center>
        <table id="example1" class="table table-striped">
          <tr>
            <th>Nom</th>
            <th><input type="text" name="nom" value=""/>
                <span id="msg" style="color:red"></span>
                 <input type="hidden" name="id" value=""/>
            </th>

          </tr>
      
          <tr>
            <th> Prenom</th>
            <th><input type="text" name="prenom" value="" />
          
          </tr>
          <tr>
          <th> Reclamation</th>
          <th><textarea name="Reclamation"></textarea>
          </th>

        </tr>
        <tr>
          <th> Mail</th>
          <th><input type="email" name="mail" value="" required />
          </th>

        </tr>
        <tr>
            <th>Id_utilisatuer</th>
            <th>
                  <select name="id_uti" >
  
                    <?php
foreach($listerec as $caa){
?>
       <option value="<?php echo $caa['id_utlisitarur'] ?>"><?php echo $caa['id_utlisitarur'] ?></option>
         <?php } ?>
         </select>
            </th>

        </tr>
   
        </table>
        <br>
        <center>
        <td><button type="submit" name="Ajouter" value="Ajouter" class="btn btn-danger">Ajouter</button></td>
      </center>
    
      </form>
              </div>
    </div>

    <!-- Subscribe Form Ends Here -->



    <!-- Footer Starts Here -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="logo">
                        <img src="assets/images/header-logo.png" alt="">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="#">Help</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">How It Works ?</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="social-icons">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Ends Here -->


    <!-- Sub Footer Starts Here -->
    <div class="sub-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright-text">
                        <p>Copyright &copy; 2022 coole as code web project

                            - Design: <a rel="nofollow" href="https://www.facebook.com/tooplate">Tooplate</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Sub Footer Ends Here -->


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>


    

</body>

</html>