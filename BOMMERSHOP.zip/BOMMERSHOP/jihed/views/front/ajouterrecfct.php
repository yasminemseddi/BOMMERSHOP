<?php
include_once '../../config.php';
include '../../controller/reclamationC.php';


include '../../model/reclamation.php';



 if(!isset($_POST['id'])||!isset($_POST['nom'])||!isset($_POST['prenom'])||!isset($_POST['Reclamation'])||!isset($_POST['mail']))
{
	echo "erreur de ";
}
$reclamationC=new reclamationC();

$res=new reclamation($_POST['id'],$_POST['nom'],$_POST['prenom'],$_POST['Reclamation'],$_POST['mail'],$_POST['id_uti']);
$rec=$reclamationC->AJouterrec($res);
header('location:index.php');
?>