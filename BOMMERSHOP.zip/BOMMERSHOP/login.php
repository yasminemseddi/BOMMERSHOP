<?php
session_start();
$username="user";
$password="123";

if(isset($_POST['username']) && $_POST['username'] == $username && $_POST['password'] == $password)
{
    header("Location: Livraison/ListeLivraisons.php");
}
else
{
?>

<html>
    <head>
    </head>
    <body>
        <div style='text-align:center'>
        <h3>Utilisateur en ligne</h3>
        </div>
        <hr /><br />
        <form id='login' action="" method='post' accept-charset='UTF-8'>
            <fieldset style="width:550px">
            <legend>Admin Login</legend>
            <input type='hidden' name='submitted' id='submitted' value='1'/>

            <label for='username' >UserName:</label>
            <input type='text' name='username' id='username'  maxlength="50" />


            <label for='password' >Password:</label>
            <input type='password' name='password' id='password' maxlength="50" />

            <input type='submit' name='submit' value='Submit' />
            </fieldset>
        </form>
    </body>
</html>
<?php
}
?>