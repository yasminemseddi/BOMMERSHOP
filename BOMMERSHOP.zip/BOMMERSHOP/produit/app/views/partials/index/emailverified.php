<div class="container">
	<h4>Vérification de l'e-mail terminée.</h4>
	<hr />
	<div class="">
		<a href="<?php print_link('index') ?>" class="btn btn-primary">Continuer</a>
	</div>
</div>



