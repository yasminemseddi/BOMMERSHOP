<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 't_produit', 
			'label' => 'T Produit', 
			'icon' => ''
		)
	);
		
	
	
}